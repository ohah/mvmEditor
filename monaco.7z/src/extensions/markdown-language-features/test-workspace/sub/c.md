# First
# Second

[b](/b.md)
[b](../b.md)
[b](./../b.md)
