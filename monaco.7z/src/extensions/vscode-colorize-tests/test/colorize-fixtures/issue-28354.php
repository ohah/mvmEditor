<script>
    ...
        <?php
            foreach($actID AS $act) {
                echo 'divNames.push(\'[nid='.$act.']\');';
             }
        ?>
    ...
</script>